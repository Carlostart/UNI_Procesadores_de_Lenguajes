
public class Etiqueta {

	private String v;
	private String f;

	public Etiqueta(String v, String f) {
		this.v = v;
		this.f = f;
	}

	public void setV(String v) {
		this.v = v;
	}
	public void setF(String f) {
		this.f = f;
	}
	public String v() {
		return v;
	}

	public String f() {
		return f;
	}
}